#include "ExternPara.h"

int threshold_temp=70,threshold_humi=80;  //�¶Ⱥ�ʪ�ȵ���ֵ
int Time_constant=600;  //ʱ�䳣��
unsigned char ispeople;
int Light = 0;
uint8_t counter = 0;

