#include "timer.h"
#include "led.h"

void TIM3_Int_Init(u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStrue;
	NVIC_InitTypeDef NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	
	TIM_TimeBaseInitStrue.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStrue.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitStrue.TIM_Period=arr;
	TIM_TimeBaseInitStrue.TIM_Prescaler=psc;
	
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStrue);
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x03;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM3,ENABLE);
}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)
	{
		counter++;
		printf("counter=%d",counter);
		// ����10������ƹ⿪�����Զ��رյƹ⡪������˯��
		if (RTC_TimeStruct.RTC_Hours == 22 && RTC_TimeStruct.RTC_Minutes == 0 && RTC_TimeStruct.RTC_Seconds==0 && LED2==0)
		{
				Wifi_SendData("#LL@");delay_ms(100);
				Wifi_SendData("#LL@");
		}
		//��ʱΪ����9��-16�㣬û�����ڵ��ƹ⿪��
		if(RTC_TimeStruct.RTC_Hours >= 9 && RTC_TimeStruct.RTC_Hours <16 && Light >= 100 && ispeople==0 && LED2==0 && counter >= Time_constant)
		{
				Wifi_SendData("#HH@");delay_ms(100);
				Wifi_SendData("#HH@");
				counter = 0;
		}
		//��ʱΪ����22��-05�㣬û�����ڵ��ƹ⿪��
		else if(RTC_TimeStruct.RTC_Hours >= 22 || RTC_TimeStruct.RTC_Hours <5 && ispeople==0 && LED2==0 && counter > Time_constant)
		{
				LED2=1;
				Wifi_SendData("#HL@");delay_ms(100);
				Wifi_SendData("#HL@");
				counter = 0;
		}
		if(ispeople==1)
		{
				counter = 0;
		}
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	}
}

