#ifndef __TIMER_H
#define __TIMER_H
#include "common.h"
 
void TIM1_PWM_Init(uint32_t arr,uint32_t psc);

#endif

