#ifndef __ADC3_ISPEOPLE_H
#define __ADC3_ISPEOPLE_H	
#include "common.h" 
#include "ExternPara.h"
 
 							   
void  ADC3_ispeople_Init(void); 				//ADCͨ����ʼ��
u16  Get_Adc_ispeole(u8 ch); 				//���ĳ��ͨ��ֵ 
uint8_t get_ispeople(void);
#endif 















