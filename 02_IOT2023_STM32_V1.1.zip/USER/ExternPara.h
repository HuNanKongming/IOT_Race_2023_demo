#ifndef EXTERNPARA_H
#define EXTERNPARA_H	 
#include "common.h" 
#include "ESP8266.h"
#include "led.h"
#include "beep.h"
#include "lcd.h"
#include "key.h"
#include "gpiod.h"
#include "rtc.h"
#include "timer.h"
#include "usart1.h"
#include "adc_light.h"	
#include "dht11.h"
#include "adc_ispeople.h"
extern int threshold_temp,threshold_humi;
extern int Time_constant;
extern unsigned char ispeople;
extern int Light;
extern uint8_t counter;
void Time_Display(void);
#endif
