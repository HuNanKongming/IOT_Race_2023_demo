#ifndef __GPIO_H
#define __GPIO_H
#include "common.h"

void GPIOd_I12_13nit(void);
void GPIOE_I8_10nit(void);
void GPIOF_1_0nit(void);
void GPIOE_I14_11Init(void);//��ʼ����ˮ��
#endif

