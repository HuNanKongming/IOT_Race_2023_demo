#include "ExternPara.h"
#include "rtc.h"
/*********************************************************************************
**********************MCU���� STM32F407Ӧ�ÿ�����(�����)*************************
**********************************************************************************
* �ļ�����: 2023�����ʡ������Ӧ�ô�����ƾ���                               *
* �ļ�����������ɨ�����                                                        *
* �������ڣ�2024.11.20                                                           *
* ��    ����V1.1                                                                 *
* ��    �ߣ��򾲲�                                                              *
* ˵    �������ܼҾ� 												                                   * 
**********************************************************************************�B
*********************************************************************************/
u8 const *weekdate[7]={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
u8 const *set_option[6]={"Year","Month","Day","Hours","Minutes","Seconds"};

extern DHT11_Data_TypeDef DHT11_Data;
void Time_Display(void)
{
	Scan_key();
	BRUSH_COLOR=BLACK; 
		RTC_GetTime(RTC_Format_BIN,&RTC_TimeStruct);
		LCD_DisplayString(30,20,16,"Date:20  -  -  ");
		LCD_DisplayNum(86,20,RTC_DateStruct.RTC_Year,2,16,1);
		LCD_DisplayNum(110,20,RTC_DateStruct.RTC_Month,2,16,1);
		LCD_DisplayNum(134,20,RTC_DateStruct.RTC_Date,2,16,1);
		LCD_DisplayString(30,40,16,"Time:  :  :  ");
		LCD_DisplayNum(70,40,RTC_TimeStruct.RTC_Hours,2,16,1);	
		LCD_DisplayNum(94,40,RTC_TimeStruct.RTC_Minutes,2,16,1);
		LCD_DisplayNum(118,40,RTC_TimeStruct.RTC_Seconds,2,16,1);
		LCD_DisplayString(30,60,16,"Week:        ");
		LCD_DisplayString(70,60,16,(u8 *)weekdate[RTC_DateStruct.RTC_WeekDay-1]);
	
	LCD_DisplayString(20,80,16," =======Threshold======");
	LCD_DisplayString(39,100,16," T_Temp:     T_humi:   ");
	LCD_DisplayNum(105,100,threshold_temp,2,16,1);	
	LCD_DisplayNum(200,100,threshold_humi,2,16,1);
	LCD_DisplayString(39,120,16," T_Const:      ST    ");
	LCD_DisplayNum(105,120,Time_constant,4,16,1);
	LCD_DisplayNum(200,120,counter,4,16,1);
	LCD_DisplayString(20,180,16,"=========Data=========");
	BRUSH_COLOR=RED; 
	LCD_DisplayString(39,200,16," Temp:     humi:  ");
	LCD_DisplayNum(95,200,DHT11_Data.temp_int,2,16,1);	
	LCD_DisplayNum(180,200,DHT11_Data.humi_int,2,16,1);
	LCD_DisplayString(39,220,16," light:     People:   ");
	LCD_DisplayNum(95,220,Light,3,16,1);	
	LCD_DisplayNum(200,220,ispeople,1,16,1);
}

u8 T1 = 0,T2 = 0,TH=0,humi;
char message[50];
int main(void)
{   
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);      
	LED_Init();		  		
	BEEP_Init();         
	KEY_Init();
	delay_init();	
	uart1_init(115200);
	ESP8266_Init();
	RTC_InitConfig();
	TIM3_Int_Init(9999, 8399);
	LCD_Init();
	ADC3_light_Init();
	DHT11_Mode_Init();
	ADC3_ispeople_Init();
	while(1)
	{		
		Scan_key();
		get_ispeople();
		RTC_GetTimes(RTC_Format_BIN);
		Time_Display();
		Light = get_light();
		if(DHT11_ReadData(&DHT11_Data) == 1){
				sprintf(message, "{\"temperature\": %d, \"humidity\": %d, \"light\": %d}", DHT11_Data.temp_int, DHT11_Data.humi_int, Light);
				Wifi_SendData(message);
		}
		delay_ms(100);
		if(DHT11_Data.temp_int>threshold_temp){
			BEEP_ON();
			delay_ms(100);
			BEEP_OFF();
			Wifi_SendData("#TH@");
		}else{
		}
	}
}

