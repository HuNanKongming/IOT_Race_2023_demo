package com.example.iot2024;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Calendar;
import android.annotation.SuppressLint;
import android.app.*;
import android.os.*;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import androidx.core.app.NotificationCompat;

public class tcpActivity extends Activity implements OnClickListener {
    Socket socket=null;//开辟一个socket控件
    Button enterbut=null;//
    EditText IP=null;
    EditText PORT=null;
    EditText edttemp=null;//温度
    EditText edthumi=null;//湿度
    EditText edtlight=null;//光照
    EditText edttime=null;
    EditText edittext=null;
    OutputStream outputstream;
    InputStream in;
    boolean isConnected=false;
    boolean led1data=false,led2data=false;
    boolean but1flag=false,but2flag=false;
    private Button btn;
    private Button btntime_h;
    private Button btnjiaozhun;
    private TextView tv1;
    private EditText EditView9;
    private EditText EditView10;
    private Button btn9;
    private Button btn_led1_open;
    private Button btn_led1_close;
    private Button btn_send;
    int year;
    int month;  // 月份从0开始，所以下月需要加1
    int day;
    int hour;
    int minute;
    int second;
    @Override
    public String toString() {
        return "tcpActivity{" +
                "text=" + text +
                '}';
    }
    private int text=35;
    private EditText editText8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tcp);
        enterbut=(Button)findViewById(R.id.conn);//获取ID号
        IP=(EditText)findViewById(R.id.editIp);
        IP.setText("192.168.1.12");
        PORT=(EditText)findViewById(R.id.editport);
        tv1 = findViewById(R.id.textView6);
        PORT.setText("5000");
        btn9 = findViewById(R.id.btn9);
        editText8 = findViewById(R.id.EditView8);
        edittext = findViewById(R.id.edittext);
        EditView9 = findViewById(R.id.EditView9);
        EditView10 = findViewById(R.id.EditView10);
        btnjiaozhun = findViewById(R.id.btnjiaozhun);
        edttemp=(EditText)findViewById(R.id.edittemp);
        edthumi=(EditText)findViewById(R.id.edithumi);
        edtlight=(EditText)findViewById(R.id.editlight);
        edttime=(EditText)findViewById(R.id.edittime);
        enterbut.setOnClickListener(new enterclick());
        btn = findViewById(R.id.btn8);
        btntime_h = findViewById(R.id.btntime_h);
        btn_led1_open = findViewById(R.id.btn_led1_open);
        btn_led1_close = findViewById(R.id.btn_led1_close);
        edittext.setText("ST1000E");
        btn_send = findViewById(R.id.btn_send);
        btntime_h.setOnClickListener(this);
        btn_led1_open.setOnClickListener(this);
        btn_led1_close.setOnClickListener(this);
        btn.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn_send.setOnClickListener(this);
        btntime_h.setOnClickListener(this);
        btnjiaozhun.setOnClickListener(this);
        enterbut.performClick();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btn8)
        {
            try {
                // 获取 EditText 中的文本内容，并将其转换为字符串
                String editTextContent = editText8.getText().toString();
                Log.d("EditTextContent", "内容是: " + editTextContent);
                // 添加针头和针尾
                String formattedContent = "SC" + editTextContent + "E";
                Log.d("FormattedContent", "发送内容是: " + formattedContent);
                // 通过 Sender 类发送数据
                Sender sender = new Sender(formattedContent);
                sender.start();
                Toast.makeText(tcpActivity.this,"发送数据成功！"	,Toast.LENGTH_SHORT ).show();
            }
            catch (Exception e) {
                Log.e("Error", "发送数据时出错: " + e.getMessage());
            }
        }
        else if(view.getId() == R.id.btntime_h)
        {
            try {
                String editTextContent = EditView9.getText().toString();
                Log.d("EditTextContent", "内容是: " + editTextContent);
                // 添加针头和针尾
                String formattedContent = "SH" + editTextContent + "E";
                Log.d("FormattedContent", "发送内容是: " + formattedContent);
                // 通过 Sender 类发送数据
                Sender sender = new Sender(formattedContent);
                sender.start();
                Toast.makeText(tcpActivity.this,"发送数据成功！"	,Toast.LENGTH_SHORT ).show();
            }
            catch (Exception e) {
                Log.e("Error", "发送数据时出错: " + e.getMessage());
            }
        }else if(view.getId() == R.id.btn9)
        {
            try {
                String editTextContent = EditView10.getText().toString();
                Log.d("EditTextContent", "内容是: " + editTextContent);
                // 添加针头和针尾
                String formattedContent = "SM" + editTextContent + "E";
                Log.d("FormattedContent", "发送内容是: " + formattedContent);
                // 通过 Sender 类发送数据
                Sender sender = new Sender(formattedContent);
                sender.start();
                Toast.makeText(tcpActivity.this,"发送数据成功！"	,Toast.LENGTH_SHORT ).show();
            }
                catch (Exception e) {
                Log.e("Error", "发送数据时出错: " + e.getMessage());
            }
        }
        else if(view.getId() == R.id.btnjiaozhun)
        {
            String dateTime = String.format("SF%d-%02d-%02d %02d:%02d:%02dE", year, month, day, hour, minute, second);
            Sender sender = new Sender(dateTime);
            sender.start();
        }
        else if(view.getId() == R.id.btn_send)
        {
            // 获取 EditText 对象
            EditText editText = findViewById(R.id.edittext);
            // 获取输入的字符串
            String dataToSend = editText.getText().toString().trim();
            // 检查输入是否为空
            if (dataToSend.isEmpty()) {
                Toast.makeText(this, "请输入内容后再发送", Toast.LENGTH_SHORT).show();
                return;
            }
            // 创建并启动线程发送数据
            Sender sender = new Sender(dataToSend);
            sender.start();
        }
        else if(view.getId() == R.id.btn_led1_open)
        {
            String dataToSend = "Sopen_led3E";
            Sender sender = new Sender(dataToSend);
            sender.start();
        }
        else if(view.getId() == R.id.btn_led1_close)
        {
            String dataToSend = "Sclose_led3E";
            Sender sender = new Sender(dataToSend);
            sender.start();
        }
    }
/****************定义按键触发事件函数*******************/
    public class enterclick implements OnClickListener
    {
        @Override
        public void onClick(View arg0) {
            // TODO Auto-generated method stub
            if(!isConnected)//没有连接上
                new ClientThread().start();//打开连接
            else//连接上，断开连接
            {
                if (socket != null) {
                    try {
                        socket.close();
                        socket = null;
                        isConnected=false;
                        //得到一个消息对象，Message类是有Android操作系统提供
                        Message msg = mHandler.obtainMessage();
                        msg.what=0;
                        mHandler.sendMessage(msg);
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    Handler mHandler = new Handler() {  // 等待socket连接成功
        @SuppressLint("HandlerLeak")
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0: // TCP断开连接
                    enterbut.setText("连接");
                    Toast.makeText(tcpActivity.this, "服务器连接断开！", Toast.LENGTH_SHORT).show();
                    break;
                case 1: // 表明TCP连接成功，可以进行数据交互了
                    enterbut.setText("断开");
                    Toast.makeText(tcpActivity.this, "服务器连接成功！", Toast.LENGTH_SHORT).show();
                    new InputThread().start(); // 开启接收线程
                    break;
                case 2: // 有数据进来
                    try {
                        String result = msg.getData().get("msg").toString();
                        // 检查针头和针尾
                        if (result.startsWith("#") && result.charAt(result.length() - 2) == '@') {
                            Log.d("DataFormatError", "收到数据格式是: " + result);
                            String data2 = result.substring(1, result.length() - 2);
                            if (data2.equals("TH")) {
                                showToastCentered("温度高于上限");
                                wakeUpAndNotify("火灾警告", "当前温度高于上限，请注意安全！");
                                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                if (vibrator != null && vibrator.hasVibrator()) {
                                    long[] pattern = {0, 500, 200, 500}; // 停止->震动->停止->震动
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        VibrationEffect vibrationEffect = VibrationEffect.createWaveform(pattern, -1); // -1 表示不重复
                                        vibrator.vibrate(vibrationEffect);
                                    } else {
                                        vibrator.vibrate(pattern, -1); // -1 表示不重复
                                    }
                                }
                            } else if (data2.equals("LL")) {
                                // 处理 TL 数据逻辑
                                showToastCentered("睡眠提醒");
                                wakeUpAndNotify("睡眠提醒", "主人已经22点了，是否关闭灯光睡觉！");
                            } else if (data2.equals("HH")) {
                                showToastCentered("白天灯光开启但无人");
                                wakeUpAndNotify("白天灯光警告", "此时没有人但灯光开启，是否关闭灯光！");
                            } else if (data2.equals("HL")) {
                                showToastCentered("夜间灯光自动关闭了");
                                wakeUpAndNotify("夜间灯光警告", "此时没有人但灯光开启，自动关闭灯光！");
                            }
                        } else if (result.startsWith("[") && result.endsWith("]")) {
                            // 去掉针头和针尾，得到实际数据
                            String data = result.substring(1, result.length() - 1);
                            edttemp.setText(data.substring(0, 2) + "°C");   // 获取温度
                            edthumi.setText(data.substring(2, 4) + "%");   // 获取湿度
                            edtlight.setText(data.substring(4, 7) + "Lux"); // 获取光照
                        } else {
                            Log.e("DataFormatError", "收到数据格式不正确: " + result);
                            result = ""; // 清空无效数据
                        }
                    } catch (StringIndexOutOfBoundsException e) {
                        Log.e("DataParsingError", "字符串解析错误: " + e.getMessage());
                    } catch (NullPointerException e) {
                        Log.e("DataParsingError", "空指针异常: " + e.getMessage());
                    } catch (Exception e) {
                        Log.e("DataParsingError", "未知错误: " + e.getMessage());
                    }
                    break;
            }
        }
        private void wakeUpAndNotify(String title, String message) {
            // 获取 PowerManager 和 KeyguardManager
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);

            // 唤醒屏幕
            if (powerManager != null && !powerManager.isInteractive()) {
                PowerManager.WakeLock wakeLock = powerManager.newWakeLock(
                        PowerManager.FULL_WAKE_LOCK |
                                PowerManager.ACQUIRE_CAUSES_WAKEUP |
                                PowerManager.ON_AFTER_RELEASE,
                        "YourApp:WakeUpLock"
                );
                wakeLock.acquire(3000); // 唤醒屏幕持续3秒
            }
            // 震动提醒
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) { // 检查是否支持震动
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Android 8.0 及以上使用 VibrationEffect
                    VibrationEffect vibrationEffect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE);
                    vibrator.vibrate(vibrationEffect);
                } else {
                    // 低于 Android 8.0
                    vibrator.vibrate(500); // 振动500毫秒
                }
            }
            // 发送通知
            sendNotification(title, message);
        }

        // 居中显示Toast的方法
        private void showToastCentered(String message) {
            Toast toastCenter = Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT);
            toastCenter.setGravity(Gravity.CENTER, 0, 0);
            toastCenter.show();
        }
    };
    private void wakeUpAndNotify(String title, String message) {
        // 获取 PowerManager 和 KeyguardManager
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);

        // 唤醒屏幕
        if (powerManager != null && !powerManager.isInteractive()) {
            PowerManager.WakeLock wakeLock = powerManager.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK |
                            PowerManager.ACQUIRE_CAUSES_WAKEUP |
                            PowerManager.ON_AFTER_RELEASE,
                    "YourApp:WakeUpLock"
            );
            wakeLock.acquire(3000); // 唤醒屏幕持续3秒
        }
        // 发送通知
        sendNotification(title, message);
    }
    private void sendNotification(String title, String message) {
        String channelId = "TemperatureAlert";
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // 创建通知渠道（适用于 Android 8.0+）
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "警告通知",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("温度超限警告");
            notificationManager.createNotificationChannel(channel);
        }
        // 构建通知
        Notification notification = new NotificationCompat.Builder(this, channelId)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.drawable.ic_launcher_foreground) // 替换为你的图标
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build();
        // 发送通知
        notificationManager.notify(1, notification);
    }

    //开辟一个线程 ,线程不允许更新UI  socket连接使用
    public class ClientThread extends Thread
    {
        public void run()
        {
            try {
                socket=new Socket(IP.getText().toString(),Integer.parseInt(PORT.getText().toString()));//建立好连接之后，就可以进行数据通讯了
                isConnected=true;
                in = socket.getInputStream();
                //得到一个消息对象，Message类是有Android操作系统提供
                Message msg = mHandler.obtainMessage();
                msg.what=1;
                mHandler.sendMessage(msg);
            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }//连接服务器
        }
    }
    public class InputThread extends Thread {
        public void run() {
            while(true) {
                if(socket != null) {
                    String result = readFromInputStream(in);
                    try {
                        if (!result.equals("")) {
                            Message msg = new Message();
                            msg.what = 2;
                            Bundle data = new Bundle();
                            data.putString("msg", result);
                            msg.setData(data);
                            mHandler.sendMessage(msg);
                        }
                    } catch (Exception e) {
                        //Log.e(tag, "--->>read failure!" + e.toString());
                    }
                    try {
                        // 睡眠1秒，避免线程过载
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public String readFromInputStream(InputStream in) {
        int count = 0;
        byte[] inDatas = null;
        try {
            while (count == 0) {
                count = in.available();
            }
            inDatas = new byte[count];
            in.read(inDatas);
            return new String(inDatas, "gb2312");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    /* 客户端发送数据 */
    class Sender extends Thread
    {
        String serverIp;
        String message;
        Sender(String message) {
            super();
            //serverIp = serverAddress;
            this.message = message;
        }
        public void run()
        {
            PrintWriter out;
            try {
                // 向服务器端发送消息
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                out.println(message);
                out.flush();
            } catch (Exception e){
                //LogUtil.e("发送错误:[Sender]run()" + e.getMessage());
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private void updateTime() {
        Calendar calendar = Calendar.getInstance();

         year = calendar.get(Calendar.YEAR);
         month = calendar.get(Calendar.MONTH) + 1;  // 月份从0开始，所以下月需要加1
         day = calendar.get(Calendar.DAY_OF_MONTH);
         hour = calendar.get(Calendar.HOUR_OF_DAY);
         minute = calendar.get(Calendar.MINUTE);
         second = calendar.get(Calendar.SECOND);
        // 格式化时间
        String dateTime = String.format("%d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, minute, second);

        // 更新 EditText
        edttime.setText(dateTime);
    }
    private Handler timeHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            updateTime();  // 更新时间
        }
    };
    // 创建一个定时更新时间的 Runnable
    private Runnable timeRunnable = new Runnable() {
        @Override
        public void run() {
            timeHandler.sendEmptyMessage(0);  // 发送消息来更新时间
            timeHandler.postDelayed(this, 1000);  // 每隔1000ms（1秒）更新一次
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        timeHandler.post(timeRunnable);  // 开始更新时间
    }
    @Override
    protected void onPause() {
        super.onPause();
        timeHandler.removeCallbacks(timeRunnable);  // 停止更新时间
    }
}