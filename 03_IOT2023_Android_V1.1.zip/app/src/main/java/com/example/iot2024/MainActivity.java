package com.example.iot2024;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.w3c.dom.ls.LSOutput;
public class MainActivity extends Activity
{
    Button but=null;//??????????????
    EditText name=null;
    EditText password=null;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText)findViewById(R.id.loginTxtName);
        password=(EditText)findViewById(R.id.loginTxtPassword);
        name.setText("JINGBO");
        password.setText("123456");
        but=(Button)findViewById(R.id.loginBtnOk);//???ID??
        but.setOnClickListener(new setclick());
    }
    public class setclick implements OnClickListener
    {
        @SuppressLint("WrongConstant")
        @Override
        public void onClick(View arg0)
        {
            // TODO Auto-generated method stub
            String strname,strword;
            strname=name.getText().toString();
            strword=password.getText().toString();
            if(strname.equals("JINGBO")&&strword.equals("123456"))
            {
                Intent  intent=new Intent();
                intent.setClass(MainActivity.this, tcpActivity.class);
                MainActivity.this.startActivity(intent);
                Toast.makeText(MainActivity.this,"登入成功"	, 0).show();
            }
            else
                Toast.makeText(MainActivity.this,"密码错误"	, 0).show();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
